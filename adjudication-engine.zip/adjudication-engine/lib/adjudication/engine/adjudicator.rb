module Adjudication
  module Engine
    class Adjudicator
      attr_reader :processed_claims

      def initialize
        @processed_claims = []
      end


      def adjudicate(claim)
        # TODO implement adjudication rules, and add any processed claims (regardless
        # of status) into the processed_claims attribute.


#  my attempt at trying to describe how I might process each claim item
#  cdid not inlude how to remove duplicate claims

        current_claim = Claim.new(claim)
  #      puts current_claim

      paid_claim = {} 
      current_claim[line_items].each do |item|
        if item[:procedure_code].preventive_and_diagnostic?
          paid_claim = {"claim number" => current_claim["number"], "procedure code" => :procedure_code, "paid in full at " => item[:charged])
        elsif item[:procedure_code].ortho?
          paid_claim = {"claim number" => current_claim["number"], "procedure code" => :procedure_code, "paid at 25% " => (item[:charged] * .25))
        else
          $stderr.puts "Claim for #{current_claim["number"]} procedure #{item[:procedure_code]} is not covered."
        end
        @processed_claims.push(paid_claim)
      end








      end


    end
  end
end
