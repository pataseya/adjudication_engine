require "adjudication/providers/fetcher"

module Adjudication
  module Providers
  end
end
