module Adjudication
  module Engine
    VERSION = "0.1.0"
  end
end
