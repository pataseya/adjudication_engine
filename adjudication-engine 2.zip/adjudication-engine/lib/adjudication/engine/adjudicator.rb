module Adjudication
  module Engine
    class Adjudicator
      attr_reader :processed_claims

      def initialize
        @processed_claims = []
      end


      def adjudicate(claim)
        # TODO implement adjudication rules, and add any processed claims (regardless
        # of status) into the processed_claims attribute.


#  my attempt at trying to describe how I might process each claim item
#  cdid not inlude how to remove duplicate claims

    #    current_claim = Claim.new(claim)
  #      puts current_claim









      end


    end
  end
end
